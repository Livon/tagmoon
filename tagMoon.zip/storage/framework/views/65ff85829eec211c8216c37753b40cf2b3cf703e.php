<?php $__env->startSection('pageTitle','详情 - TagMoon'); ?>




<?php $__env->startSection('pageBody'); ?>


    <!-- Start your project here-->
<div style="height: 10vh">
    <div class="flex-center flex-column">
        <h1 class="animated fadeIn mb-4">详情</h1>
    </div>
</div>

<?php echo e($item -> id); ?> <br>
<?php echo e($item -> name); ?> <br>
<?php echo e($item -> done); ?> <br>

<a href="/tagMoon/public/item/edit/<?php echo e($item -> id); ?>" target="_blank">修改<br></a>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('myJavascript'); ?>
    <script type="text/javascript" src="../../public/js/item/detail.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>