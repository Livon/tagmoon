<?php $__env->startSection('pageTitle','View - TagMoon'); ?>


<?php $__env->startSection('myCss'); ?>

<link rel="stylesheet" href="../../../../markdown\sparksuite-simplemde-markdown-editor-1.11.2-0-g6abda7a\demo\font-awesome.min.css">
<link rel="stylesheet" href="../../../../markdown\sparksuite-simplemde-markdown-editor-1.11.2-0-g6abda7a\dist\simplemde.min.css">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('pageBody'); ?>

    <script type="text/javascript">
        var articleId = '<?php echo e($article -> id); ?>';
        var articleContent = '<?php echo e($article -> name); ?>';
    </script>


    <!-- Start your project here-->
<div style="height: 10vh">
    <div class="flex-center flex-column">
        <h1 class="animated fadeIn mb-4">View</h1>
    </div>
</div>
<!-- /Start your project here-->



    
    <div id="div_articleTags"></div>

    <div id="div_article"></div>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('myJavascript'); ?>

<script src="../../../public/js/article/view.js" type="text/javascript"></script>
<script src="../../../public/js/itemTags/main.js" type="text/javascript"></script>

<script>

    // SMDE = SimpleMarkdownEditor
    var SMDE;
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>