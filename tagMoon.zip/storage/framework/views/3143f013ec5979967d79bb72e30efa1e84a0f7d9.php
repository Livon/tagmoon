<p>( \reources\views\layouts\master.blade.php )永</p>

<p>title: <?php echo $__env->yieldContent('title'); ?></p>

<p>content: <?php echo $__env->yieldContent('content'); ?></p>
