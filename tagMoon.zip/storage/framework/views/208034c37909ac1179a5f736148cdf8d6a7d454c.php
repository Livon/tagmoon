<?php $__env->startSection('title','峰'); ?>

<?php $__env->startSection('content'); ?>
杨<br>
Yang
<?php $__env->stopSection(); ?>
/*
|--------------------------------------------------------------------------
| Run The Application
|--------------------------------------------------------------------------
|
| Once we have the application, we can handle the incoming request
| through the kernel, and send the associated response back to
| the client's browser allowing them to enjoy the creative
| and wonderful application we have prepared for them.
|
|<?php $__currentLoopData = $ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
|
|    <p><?php echo e($id); ?></p>
|
|<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
*/


<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <p>

    <?php echo e($task->id); ?> - <?php echo e($task->name); ?>


    <?php if(!$task->done): ?>
        <span style="color: #d58512"><?php echo e($task->done); ?></span>
    <?php endif; ?>

    <span style="color: #77ee77"><?php echo e(($task->done)?'完成啦！':'再等等'); ?></span>

    </p>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<p>Livon</p>

<p>http://php.net/manual/zh/control-structures.foreach.php</p>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>