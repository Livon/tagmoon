<?php $__env->startSection('pageTitle','列表 - TagMoon'); ?>




<?php $__env->startSection('pageBody'); ?>


    <!-- Start your project here-->
<div style="height: 10vh">
    <div class="flex-center flex-column">
        <h1 class="animated fadeIn mb-4">列表</h1>
    </div>
</div>

<h3>2、做为检索条件的标签</h3>
<div id="div_tag_queryCondition"></div>

<div class="md-form">
    <i class="fa fa-tag prefix"></i>
    <input type="text" id="input_tag_search" class="form-control">
    <label for="form2">请输入检索标签</label>
</div>

<h3>3、标签搜索结果</h3>
<div id="div_tag_searchResult"></div>
<h3>4、最近使用标签</h3>
<div id="div_tag_recentlyUsed"></div>
<h3>5、内容标签</h3>
<div id="div_tag_itemsTags"></div>



<div class="md-form">
    <i class="fa fa-search prefix"></i>
    <input type="text" id="input_item_search" class="form-control">
    <label for="form2">请输入检索内容，用空格间隔</label>
</div>

<h3>6、内容搜索结果</h3>
<div id="div_items_pagination_link"></div>
<div id="div_items"></div>

<i class="fa fa-android fa-2x" aria-hidden="true"></i>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">确定删除吗？</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" data-dismiss="modal" tagId="">确定删除</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('myJavascript'); ?>
    <script type="text/javascript" src="../../public/js/item/list.js"></script>
    <script type="text/javascript" src="../../public/js/tag/recentlyUsed.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
