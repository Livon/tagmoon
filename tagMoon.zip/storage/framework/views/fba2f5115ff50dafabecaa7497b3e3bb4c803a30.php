<?php $__env->startSection('title','峰'); ?>

<?php $__env->startSection('content'); ?>
杨
Yang
<?php $__env->stopSection(); ?>

<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php echo e($task->name); ?>


    <?php if(!$task->done): ?>
        <?php echo e($task->done); ?>

    <?php endif; ?>

    <?php echo e(($task->done)?'完成啦！':'再等等'); ?>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>