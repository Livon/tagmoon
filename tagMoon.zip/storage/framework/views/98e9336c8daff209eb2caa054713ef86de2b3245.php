<?php $__env->startSection('pageTitle','上传图片 - TagMoon'); ?>


<?php $__env->startSection('myCss'); ?>

    <link rel="stylesheet" href="../../../public/css/upload-img.css">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('pageBody'); ?>

    <div class="form-group row">
        <label class="col-md-2 control-label">缩略图</label>
        <div class="col-md-4 thumb-wrap">
            <div class="pic-upload btn btn-block btn-info btn-flat" title="点击上传">点击上传</div>
            <img id="logo" src="">
            <input type="hidden" name="logo" value="">
        </div>
    </div>

    <?php echo $__env->make('item.upload_img', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('myJavascript'); ?>

    <script>
        $(function(){
            //上传图片相关

            $('.upload-mask').on('click',function(){
                $(this).hide();
                $('.upload-file').hide();
            })

            $('.upload-file .close').on('click',function(){
                $('.upload-mask').hide();
                $('.upload-file').hide();
            })

            var imgSrc = $('.pic-upload').next().attr('src');
            console.log(imgSrc);
            if(imgSrc == ''){
                $('.pic-upload').next().css('display','none');
            }
            $('.pic-upload').on('click',function(){
                $('.upload-mask').show();
                $('.upload-file').show();
                console.log($(this).next().attr('id'));
                var imgID = $(this).next().attr('id');
                $('#imgID').attr('value',imgID);
            })


            //ajax 上传
            $(document).ready(function() {
                var options = {
                    beforeSubmit:  showRequest,
                    success:       showResponse,
                    dataType: 'json'
                };
                $('#imgForm input[name=file]').on('change', function(){
                    //$('#upload-avatar').html('正在上传...');
                    $('#imgForm').ajaxForm(options).submit();
                });
            });

            function showRequest() {
                $("#validation-errors").hide().empty();
                $("#output").css('display','none');
                return true;
            }

            function showResponse(response)  {
                if(response.success == false)
                {
                    var responseErrors = response.errors;
                    $.each(responseErrors, function(index, value)
                    {
                        if (value.length != 0)
                        {
                            $("#validation-errors").append('<div class="alert alert-error"><strong>'+ value +'</strong><div>');
                        }
                    });
                    $("#validation-errors").show();
                } else {

                    $('.upload-mask').hide();
                    $('.upload-file').hide();
                    $('.pic-upload').next().css('display','block');

                    console.log(response.pic);

                    $("#"+response.id).attr('src',response.pic);
                    $("#"+response.id).next().attr('value',response.pic);
                }
            }

        })
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>