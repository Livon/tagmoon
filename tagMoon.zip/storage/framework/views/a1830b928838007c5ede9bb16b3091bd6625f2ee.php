<!--

 --------------------------------------------------------------------------
  Run The Application
 --------------------------------------------------------------------------

  Once we have the application, we can handle the incoming request
  through the kernel, and send the associated response back to
  the client's browser allowing them to enjoy the creative
  and wonderful application we have prepared for them.

-->



<?php $__env->startSection('title','峰'); ?>

<?php $__env->startSection('content'); ?>
杨<br>
Yang
<?php $__env->stopSection(); ?>

<p><?php echo e($insertedId); ?></p>

<p>Livon</p>

<p>http://php.net/manual/zh/control-structures.foreach.php</p>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>