<?php
/**
 * Created by PhpStorm.
 * User: Livon
 * Date: 2018/1/24
 * Time: 21:40
 */

// https://d.laravel-china.org/docs/5.4/queries

