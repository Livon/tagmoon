<!--

 --------------------------------------------------------------------------
  Run The Application
 --------------------------------------------------------------------------

  Once we have the application, we can handle the incoming request
  through the kernel, and send the associated response back to
  the client's browser allowing them to enjoy the creative
  and wonderful application we have prepared for them.

-->

@extends('layouts.master')

@section('title','峰')

@section('content')
杨<br>
Yang
@endsection

<p>{{ $insertedId }}</p>

<p>Livon</p>

<p>http://php.net/manual/zh/control-structures.foreach.php</p>
