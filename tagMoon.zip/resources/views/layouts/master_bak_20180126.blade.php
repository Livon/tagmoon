<p>( \reources\views\layouts\master.blade.php )永</p>

<p>title: @yield('title')</p>

<p>content: @yield('content')</p>
