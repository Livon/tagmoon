/**
 * Created by Livon on 2018/1/25.
 */

namespace.reg('tag');


/**
 * 监听器
 * @param search_content
 */




$(document).ready(function () {

    console.log( '2018.02.01 15:17' );

});
// end of ready


